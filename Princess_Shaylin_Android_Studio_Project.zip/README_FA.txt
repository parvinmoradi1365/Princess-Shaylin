Princess Shaylin — پروژه اندروید
این پروژه یک بازی پلتفرمر HTML5 را داخل اپ اندروید تمام‌صفحه اجرا می‌کند.
ساخت APK:
1) Android Studio نسخه جدید را نصب کنید.
2) این پوشه را با Open باز کنید.
3) اجازه دهید Gradle Sync و Android SDK مورد نیاز نصب شود.
4) از منوی Build گزینه Build APK(s) را بزنید.
فایل خروجی معمولاً در app/build/outputs/apk/debug/app-debug.apk قرار می‌گیرد.
شناسه برنامه: com.princessshaylin.game
حداقل اندروید: Android 6.0 (API 23)
کنترل: دکمه‌های لمسی داخل بازی.
توجه: این محیط به Android SDK/Gradle و شبکه دانلود ابزارها دسترسی نداشت؛ بنابراین APK کامپایل‌شده در اینجا تولید نشده است.
